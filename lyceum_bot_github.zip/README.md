# Litsey Telegram Boti

Ushbu bot litsey o'quvchilariga o'zaro ID orqali xabar almashish imkonini beradi. Barcha yozishmalar admin nazoratidan o'tib turadi.

## Fayllar tuzilishi:
- `main.py` - Botning asosiy kodi
- `requirements.txt` - Kerakli Python kutubxonalari
- `Procfile` - Render.com hostingi uchun ishga tushirish fayli
