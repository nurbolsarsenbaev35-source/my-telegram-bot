import logging
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

# Logging sozlamalari
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)

# Environment variables dan TOKEN va SUPER_ADMIN_ID ni olish (Render.com uchun qulay va xavfsiz)
TOKEN = os.getenv("TOKEN", "9191651351:AAGhP5LYll-sr5GjjTgGpN6cwELFJZfy4rs")
SUPER_ADMIN_ID = int(os.getenv("SUPER_ADMIN_ID", "5065549237"))

# Ma'lumotlar bazasi o'rnida lug'at va to'plamlar
admins = {SUPER_ADMIN_ID}
users = {}  # {user_id: username_yoki_name}
user_states = {}  # Foydalanuvchi holatini saqlash uchun


# /start buyrug'i
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    users[user.id] = user.full_name or user.username or f"User_{user.id}"

    text = f"Assalomu alaykum, {user.first_name}! Litsey botiga xush kelibsiz."
    
    if user.id in admins:
        text += "\n\nSiz adminsiz. Admin panelni ochish uchun /admin buyrug'ini yuboring."
    
    await update.message.reply_text(text)


# Admin Paneli
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in admins:
        await update.message.reply_text("Sizda admin huquqlari yo'q.")
        return

    keyboard = [
        [InlineKeyboardButton("➕ Admin qo'shish", callback_data="add_admin")],
        [InlineKeyboardButton("➖ Admin o'chirish", callback_data="remove_admin")],
        [InlineKeyboardButton("👥 O'quvchilar ro'yxati", callback_data="list_users")],
        [InlineKeyboardButton("📨 Xabar yuborish (ID orqali)", callback_data="send_msg_id")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("⚙️ **Admin Paneli:**", reply_markup=reply_markup, parse_mode="Markdown")


# Callback tugmalarini boshqarish
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    if user_id not in admins:
        return

    data = query.data

    if data == "add_admin":
        user_states[user_id] = "waiting_for_add_admin_id"
        await query.message.reply_text("Yangi adminning Telegram ID raqamini yuboring:")

    elif data == "remove_admin":
        user_states[user_id] = "waiting_for_remove_admin_id"
        await query.message.reply_text("O'chiriladigan adminning Telegram ID raqamini yuboring:")

    elif data == "list_users":
        if not users:
            await query.message.reply_text("Hozircha foydalanuvchilar yo'q.")
            return
        
        user_list_text = "👥 **Foydalanuvchilar ro'yxati:**\n\n"
        keyboard = []
        for u_id, u_name in users.items():
            user_list_text += f"ID: `{u_id}` — {u_name}\n"
            keyboard.append([InlineKeyboardButton(f"✉️ {u_name} ga xabar", callback_data=f"send_to_{u_id}")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.message.reply_text(user_list_text, parse_mode="Markdown", reply_markup=reply_markup)

    elif data == "send_msg_id":
        user_states[user_id] = "waiting_for_target_id"
        await query.message.reply_text("Xabar yubormoqchi bo'lgan foydalanuvchi ID raqamini kiriting:")

    elif data.startswith("send_to_"):
        target_id = int(data.split("_")[2])
        context.user_data["target_id"] = target_id
        user_states[user_id] = "waiting_for_message_content"
        await query.message.reply_text(f"ID: `{target_id}` ga yuboriladigan xabarni kiriting:", parse_mode="Markdown")


# Matnli xabarlarni qayta ishlash
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    text = update.message.text

    users[user_id] = user.full_name or user.username or f"User_{user.id}"

    # Admin amallari holatini tekshirish
    if user_id in user_states:
        state = user_states[user_id]

        if state == "waiting_for_add_admin_id":
            try:
                new_admin_id = int(text)
                admins.add(new_admin_id)
                await update.message.reply_text(f"✅ ID `{new_admin_id}` admin qilib qo'shildi.", parse_mode="Markdown")
            except ValueError:
                await update.message.reply_text("❌ Xato! Faqat raqamlardan iborat ID kiriting.")
            del user_states[user_id]
            return

        elif state == "waiting_for_remove_admin_id":
            try:
                rem_admin_id = int(text)
                if rem_admin_id == SUPER_ADMIN_ID:
                    await update.message.reply_text("❌ Bosh adminni o'chira olmaysiz!")
                elif rem_admin_id in admins:
                    admins.remove(rem_admin_id)
                    await update.message.reply_text(f"✅ ID `{rem_admin_id}` adminlar ro'yxatidan o'chirildi.", parse_mode="Markdown")
                else:
                    await update.message.reply_text("❌ Bu ID adminlar ro'yxatida topilmadi.")
            except ValueError:
                await update.message.reply_text("❌ Xato! Faqat raqamlardan iborat ID kiriting.")
            del user_states[user_id]
            return

        elif state == "waiting_for_target_id":
            try:
                target_id = int(text)
                context.user_data["target_id"] = target_id
                user_states[user_id] = "waiting_for_message_content"
                await update.message.reply_text(f"ID: `{target_id}` ga yuboriladigan xabarni yozing:", parse_mode="Markdown")
            except ValueError:
                await update.message.reply_text("❌ Xato! ID raqam bo'lishi kerak.")
                del user_states[user_id]
            return

        elif state == "waiting_for_message_content":
            target_id = context.user_data.get("target_id")
            try:
                await context.bot.send_message(
                    chat_id=target_id,
                    text=f"📩 **Sizga xabar keldi:**\n\n{text}",
                    parse_mode="Markdown"
                )
                await update.message.reply_text("✅ Xabar muvaffaqiyatli yuborildi.")
            except Exception as e:
                await update.message.reply_text(f"❌ Xabar yuborishda xatolik: {e}")
            
            del user_states[user_id]
            if "target_id" in context.user_data:
                del context.user_data["target_id"]
            return

    # O'quvchilar bir-biriga xabar yuborishi va adminga borib turishi uchun format: "ID: 123456789 Xabar matni"
    if text.startswith("ID:"):
        try:
            parts = text.split(" ", 2)
            target_id = int(parts[1])
            msg_content = parts[2]

            # Qabul qiluvchiga yuborish
            await context.bot.send_message(
                chat_id=target_id,
                text=f"💬 **Xabar ({users[user_id]} dan):**\n\n{msg_content}",
                parse_mode="Markdown"
            )
            await update.message.reply_text("✅ Xabaringiz yetkazildi.")

            # ADMINGA MONITORING UCHUN YUBORISH
            admin_log = f"👁 **Yozishma nazorati:**\n\n**Yuboruvchi:** {users[user_id]} (`{user_id}`)\n**Qabul qiluvchi ID:** `{target_id}`\n**Xabar:** {msg_content}"
            for admin_id in admins:
                try:
                    await context.bot.send_message(chat_id=admin_id, text=admin_log, parse_mode="Markdown")
                except Exception:
                    pass

        except Exception:
            await update.message.reply_text("❌ Xabar yuborish formati noto'g'ri. Namuna:\n`ID: 123456789 Salom!`", parse_mode="Markdown")
    else:
        await update.message.reply_text(
            "Boshqa o'quvchiga xabar yuborish uchun quyidagi formatda yozing:\n`ID: 123456789 Xabar matni`",
            parse_mode="Markdown"
        )


def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Bot ishga tushdi...")
    app.run_polling()


if __name__ == "__main__":
    main()
